const path=require('path');

exports.getForm= (req,res,next)=>
{
res.sendFile(path.join(__dirname,'contactusform.html'));
};

 exports.getSuccess=(req,res,next)=>
{
res.send('<h1>Form successfull submitted</h1>')
};